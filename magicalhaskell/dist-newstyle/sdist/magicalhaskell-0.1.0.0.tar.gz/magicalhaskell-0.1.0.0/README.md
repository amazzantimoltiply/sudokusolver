# magicalhaskell
