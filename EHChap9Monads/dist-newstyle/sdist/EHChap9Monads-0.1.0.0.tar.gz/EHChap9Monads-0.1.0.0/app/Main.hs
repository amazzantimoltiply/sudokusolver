module Main (main) where

import Lib ( someFunc )

main :: IO ()
main = someFunc
